/**
 * File: ExchangeRateResponse.java
 * Propósito: Contiene la representación POJO de la respuesta JSON de ExchangeRate-API
 */

package com.example.currency;

import java.util.Map;

/**
 * Clase que modela la respuesta JSON de ExchangeRate-API.
 * Contiene el código base y un mapa de conversion_rates (ej. "USD" -> 1.0).
 */
public class ExchangeRateResponse {
    /**
     * Indica si la respuesta fue exitosa (por ejemplo: "success" o "error" según la API)
     */
    public String result;

    /**
     * Código de la moneda base (por ejemplo "USD")
     */
    public String base_code;

    /**
     * Mapa de tasas de conversión relativo a base_code
     */
    public Map<String, Double> conversion_rates;

    /**
     * Constructor por defecto.
     */
    public ExchangeRateResponse() {}

    /**
     * Devuelve la tasa para una moneda concreta o null si no existe.
     *
     * @param currencyCode el código de la moneda (ej. "USD", "ARS")
     * @return la tasa como Double o null si no está presente
     */
    public Double getRateFor(String currencyCode) {
        if (conversion_rates == null) return null;
        return conversion_rates.get(currencyCode);
    }
}