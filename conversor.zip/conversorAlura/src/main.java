/**
 * File: Main.java
 * Propósito: Interfaz de consola para interactuar con el usuario y realizar conversiones de monedas.
 */

package com.example.currency;

import java.io.IOException;
import java.util.*;

/**
 * Clase principal con el menú en consola. Usa Scanner para la entrada del usuario.
 */
public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    /**
     * Lista de monedas de interés. Aceptamos "ARG" (se normaliza internamente a ARS).
     */
    private static final List<String> CURRENCIES_OF_INTEREST = Arrays.asList("ARG", "BRL", "USD");

    /**
     * Punto de entrada de la aplicación.
     *
     * @param args argumentos de línea de comandos (no usados)
     */
    public static void main(String[] args) {
        System.out.println("== Conversor de monedas usando ExchangeRate-API y Gson ==");
        System.out.println("Necesitas una API KEY de https://www.exchangerate-api.com/ (v6).");

        System.out.print("Ingresa tu API KEY (o presiona ENTER para usar 'YOUR_API_KEY' en el código): ");
        String apiKey = scanner.nextLine().trim();
        if (apiKey.isEmpty()) {
            System.out.println("Usando placeholder 'YOUR_API_KEY' (recuerda reemplazarlo en el código o ingresarlo aquí).");
            apiKey = "YOUR_API_KEY";
        }

        com.example.currency.ExchangeRateClient client = new com.example.currency.ExchangeRateClient();

        // Tomamos como base USD por default para obtener tasas sobre USD
        String base = "USD";
        com.example.currency.ExchangeRateResponse response = null;
        try {
            response = client.fetchLatestRates(apiKey, base);
        } catch (IOException | InterruptedException e) {
            System.err.println("Error al obtener tasas: " + e.getMessage());
            System.err.println("Asegúrate de que tu API KEY es correcta y tienes conexión a internet.");
            return;
        }

        if (response == null || response.conversion_rates == null) {
            System.err.println("Respuesta inválida de la API.");
            return;
        }

        com.example.currency.CurrencyConverter converter = new com.example.currency.CurrencyConverter(response.conversion_rates);

        // Filtrar monedas de interés y mostrarlas
        Map<String, Double> filtered = converter.filterCurrencies(CURRENCIES_OF_INTEREST);
        if (filtered.isEmpty()) {
            System.err.println("No se encontraron las monedas solicitadas en la respuesta. Respuesta disponible para: " + response.conversion_rates.keySet());
            return;
        }

        System.out.println("\nTasas obtenidas (base = " + response.base_code + "):");
        for (Map.Entry<String, Double> entry : filtered.entrySet()) {
            System.out.printf("  %s : %f%n", entry.getKey(), entry.getValue());
        }

        // Menú interactivo
        boolean running = true;
        while (running) {
            System.out.println("\n--- Menú ---");
            System.out.println("1) Convertir moneda");
            System.out.println("2) Recargar tasas desde la API");
            System.out.println("3) Mostrar tasas actuales");
            System.out.println("0) Salir");
            System.out.print("Elige una opción: ");
            String opt = scanner.nextLine().trim();

            switch (opt) {
                case "1":
                    realizarConversion(converter);
                    break;
                case "2":
                    try {
                        System.out.println("Recargando tasas desde la API...");
                        response = client.fetchLatestRates(apiKey, base);
                        converter = new com.example.currency.CurrencyConverter(response.conversion_rates);
                        filtered = converter.filterCurrencies(CURRENCIES_OF_INTEREST);
                        System.out.println("Tasas actualizadas.");
                    } catch (IOException | InterruptedException e) {
                        System.err.println("Error al recargar: " + e.getMessage());
                    }
                    break;
                case "3":
                    System.out.println("Tasas actuales (base = " + response.base_code + "):");
                    for (Map.Entry<String, Double> entry : filtered.entrySet()) {
                        System.out.printf("  %s : %f%n", entry.getKey(), entry.getValue());
                    }
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }

        System.out.println("Saliendo. ¡Hasta luego!");
    }

    /**
     * Muestra interfaz para realizar una conversión: pide origen, destino y cantidad, y muestra el resultado.
     *
     * @param converter instancia de CurrencyConverter
     */
    private static void realizarConversion(CurrencyConverter converter) {
        System.out.printf("Monedas disponibles: %s%n", CURRENCIES_OF_INTEREST);
        System.out.print("Introduce moneda origen (ej. ARG o ARS): ");
        String origin = scanner.nextLine().trim();
        System.out.print("Introduce moneda destino (ej. USD): ");
        String target = scanner.nextLine().trim();

        System.out.print("Introduce la cantidad a convertir: ");
        String amountStr = scanner.nextLine().trim();
        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            System.out.println("Cantidad no válida.");
            return;
        }

        Double result = converter.convert(amount, origin, target);
        if (result == null) {
            System.out.println("No se pudo convertir. Verifica que las monedas existen en las tasas actuales.");
        } else {
            System.out.printf("%.4f %s = %.4f %s%n", amount, origin.toUpperCase(), result, target.toUpperCase());
        }
    }
}
