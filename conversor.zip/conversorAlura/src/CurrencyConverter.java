/**
 * File: CurrencyConverter.java
 * Propósito: Contiene la lógica de filtrado de monedas y conversión usando las tasas obtenidas.
 */

package com.example.currency;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Clase que encapsula la lógica para convertir entre monedas usando un mapa de tasas.
 */
public class CurrencyConverter {
    /**
     * Mapa con tasas relativas a una moneda base (ej. si base es USD, conversionRates.get("ARS") devuelve ARS por 1 USD).
     */
    private final Map<String, Double> conversionRates;

    /**
     * Crea un conversor con el mapa de tasas obtenido de la API.
     *
     * @param conversionRates mapa de tasas (currency code -> tasa)
     */
    public CurrencyConverter(Map<String, Double> conversionRates) {
        this.conversionRates = (conversionRates != null) ? new HashMap<>(conversionRates) : new HashMap<>();
    }

    /**
     * Filtra y devuelve sólo las monedas pedidas (normaliza "ARG" a "ARS" si es necesario).
     *
     * @param codes lista de códigos solicitados (ej. ["ARG","BRL","USD"])
     * @return mapa (código -> tasa) sólo con las monedas encontradas
     */
    public Map<String, Double> filterCurrencies(List<String> codes) {
        Map<String, Double> result = new HashMap<>();
        for (String rawCode : codes) {
            String code = normalizeCode(rawCode);
            Double rate = conversionRates.get(code);
            if (rate != null) {
                result.put(code, rate);
            }
        }
        return result;
    }

    /**
     * Convierte una cantidad desde la moneda origen hacia la moneda destino usando las tasas que están relativas a la misma base.
     *
     * Fórmula:
     *  amount (en origen) -> convertir a base: amountInBase = amount / rateOrigin
     *  luego -> a destino: result = amountInBase * rateTarget
     *
     * @param amount cantidad en moneda origen
     * @param origin código de moneda origen (ej. "ARS")
     * @param target código de moneda destino (ej. "USD")
     * @return valor convertido o null si alguna tasa no existe
     */
    public Double convert(double amount, String origin, String target) {
        origin = normalizeCode(origin);
        target = normalizeCode(target);

        Double rateOrigin = conversionRates.get(origin);
        Double rateTarget = conversionRates.get(target);

        if (rateOrigin == null || rateTarget == null) {
            return null;
        }

        // Evitar división por cero
        if (rateOrigin == 0.0) {
            return null;
        }

        double amountInBase = amount / rateOrigin;
        double converted = amountInBase * rateTarget;
        return converted;
    }

    /**
     * Normaliza códigos de moneda: si el usuario proporciona "ARG" lo convertimos a "ARS".
     *
     * @param code código posiblemente no estándar
     * @return código normalizado
     */
    private String normalizeCode(String code) {
        if (code == null) return null;
        String upper = code.trim().toUpperCase();
        if (upper.equals("ARG")) return "ARS";
        return upper;
    }
}