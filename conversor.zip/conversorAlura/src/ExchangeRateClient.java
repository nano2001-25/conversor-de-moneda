/**
 * File: ExchangeRateClient.java
 * Propósito: Ejecuta solicitudes HTTP hacia ExchangeRate-API y parsea la respuesta usando Gson.
 */

package com.example.currency;

import com.google.gson.Gson;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/**
 * Cliente que realiza peticiones a ExchangeRate-API usando HttpClient (Java 11+).
 */
public class ExchangeRateClient {
    /**
     * Plantilla de URL para consultar tasas (ExchangeRate-API v6).
     * Sustituir {API_KEY} y {BASE} cuando se construya la URL.
     */
    private static final String ENDPOINT_TEMPLATE = "https://v6.exchangerate-api.com/v6/%s/latest/%s";

    /**
     * Instancia compartida de HttpClient.
     */
    private final HttpClient httpClient;

    /**
     * Instancia de Gson para parseo JSON.
     */
    private final Gson gson;

    /**
     * Crea un nuevo ExchangeRateClient.
     */
    public ExchangeRateClient() {
        this.httpClient = HttpClient.newHttpClient();
        this.gson = new Gson();
    }

    /**
     * Realiza una petición a ExchangeRate-API para obtener las tasas usando la moneda base indicada.
     *
     * @param apiKey clave de API para ExchangeRate-API
     * @param baseCurrency código de moneda base (ej. "USD")
     * @return ExchangeRateResponse con los datos; lanza IOException o InterruptedException en caso de fallo
     * @throws IOException cuando hay error de IO en la petición
     * @throws InterruptedException cuando la petición es interrumpida
     */
    public ExchangeRateResponse fetchLatestRates(String apiKey, String baseCurrency) throws IOException, InterruptedException {
        String url = String.format(ENDPOINT_TEMPLATE, apiKey, baseCurrency);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .GET()
                .header("Accept", "application/json")
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new IOException("HTTP error: " + response.statusCode() + " - " + response.body());
        }

        // Parsear JSON a ExchangeRateResponse usando Gson
        ExchangeRateResponse rateResponse = gson.fromJson(response.body(), ExchangeRateResponse.class);
        return rateResponse;
    }
}